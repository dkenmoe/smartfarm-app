from rest_framework import serializers
from productions.models import (
    AnimalType, AnimalBreed, WeightCategory,
    BirthRecord, AcquisitionRecord, AnimalInventory, DiedRecord
)
from productions.models import Animal, AnimalGroup
from account.models import Farm

class FarmRelatedSerializer(serializers.ModelSerializer):
    farm = serializers.PrimaryKeyRelatedField(
        queryset=Farm.objects.all(),
        required=False,
        help_text="Farm ID this record belongs to"
    )

    def create(self, validated_data):
        if 'farm' not in validated_data:
            request = self.context.get('request')
            if request and hasattr(request, 'current_farm'):
                validated_data['farm'] = request.current_farm
            elif request and hasattr(request, 'current_farm_id'):
                validated_data['farm'] = Farm.objects.get(id=request.current_farm_id)
        return super().create(validated_data)

class AnimalTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AnimalType
        fields = ['id', 'name', 'description', 'image', 'created_by', 'farms']
        read_only_fields = ['created_by']

class AnimalBreedSerializer(serializers.ModelSerializer):
    animal_type_name = serializers.CharField(source='animal_type.name', read_only=True)

    class Meta:
        model = AnimalBreed
        fields = [
            'id', 'name', 'description', 'animal_type', 'animal_type_name',
            'image', 'thumbnail', 'created_by', 'farms'
        ]
        read_only_fields = ['created_by', 'thumbnail']

class WeightCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = WeightCategory
        fields = ['id', 'min_weight', 'max_weight', 'created_by']
        read_only_fields = ['created_by']

class BirthRecordSerializer(FarmRelatedSerializer):
    created_by_name = serializers.CharField(source='created_by.username', read_only=True)
    total_born = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = BirthRecord
        fields = [
            'id', 'animal', 'animal_group', 'weight', 'number_of_male', 'number_of_female',
            'number_of_died', 'total_born', 'date_of_birth', 'notes', 'attachment',
            'created_by', 'created_by_name', 'farm'
        ]
        read_only_fields = ['created_by', 'created_by_name']

    def get_total_born(self, obj):
        return obj.number_of_male + obj.number_of_female + obj.number_of_died

    def validate(self, data):
        if data.get('animal') and data.get('animal_group'):
            raise serializers.ValidationError("Only one of 'animal' or 'animal_group' can be set.")
        if not data.get('animal') and not data.get('animal_group'):
            raise serializers.ValidationError("You must provide either 'animal' or 'animal_group'.")
        if (data.get('number_of_male', 0) + data.get('number_of_female', 0) + data.get('number_of_died', 0)) == 0:
            raise serializers.ValidationError("Total number of births must be greater than 0.")
        return data

class AcquisitionRecordSerializer(FarmRelatedSerializer):
    created_by_name = serializers.CharField(source='created_by.username', read_only=True)
    total_cost = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = AcquisitionRecord
        fields = [
            'id', 'animal', 'animal_group', 'quantity', 'weight', 'gender',
            'unit_preis', 'total_cost', 'date_of_acquisition', 'vendor',
            'receipt_number', 'notes', 'attachment', 'created_by', 'created_by_name', 'farm'
        ]
        read_only_fields = ['created_by', 'created_by_name', 'total_cost']

    def get_total_cost(self, obj):
        if obj.unit_preis and obj.quantity:
            return float(obj.unit_preis) * obj.quantity
        return 0

    def validate(self, data):
        if data.get('animal') and data.get('animal_group'):
            raise serializers.ValidationError("Only one of 'animal' or 'animal_group' can be set.")
        if not data.get('animal') and not data.get('animal_group'):
            raise serializers.ValidationError("You must provide either 'animal' or 'animal_group'.")
        if data.get('quantity', 0) <= 0:
            raise serializers.ValidationError("Quantity must be greater than 0.")
        if data.get('unit_preis', 0) <= 0:
            raise serializers.ValidationError("Unit price must be greater than 0.")
        return data

class AnimalInventorySerializer(FarmRelatedSerializer):
    animal_type_name = serializers.CharField(source='animal_type.name', read_only=True)
    breed_name = serializers.CharField(source='breed.name', read_only=True)

    class Meta:
        model = AnimalInventory
        fields = [
            'id', 'animal_type', 'animal_type_name', 'breed', 'breed_name',
            'quantity', 'farm'
        ]

    def validate(self, data):
        animal_type = data.get('animal_type')
        breed = data.get('breed')
        if breed and animal_type and breed.animal_type != animal_type:
            raise serializers.ValidationError("The selected breed does not belong to the specified animal type.")
        return data

class DiedRecordSerializer(FarmRelatedSerializer):
    created_by_name = serializers.CharField(source='created_by.username', read_only=True)

    class Meta:
        model = DiedRecord
        fields = [
            'id', 'animal', 'animal_group', 'weight', 'quantity', 'date_of_death',
            'cause', 'notes', 'status', 'attachment', 'created_by', 'created_by_name', 'farm'
        ]
        read_only_fields = ['created_by', 'created_by_name']

    def validate(self, data):
        if data.get('animal') and data.get('animal_group'):
            raise serializers.ValidationError("Only one of 'animal' or 'animal_group' can be set.")
        if not data.get('animal') and not data.get('animal_group'):
            raise serializers.ValidationError("You must provide either 'animal' or 'animal_group'.")
        if data.get('quantity', 0) <= 0:
            raise serializers.ValidationError("Quantity must be greater than 0.")
        if data.get('weight', 0) <= 0:
            raise serializers.ValidationError("Weight must be greater than 0.")
        return data

class AnimalSerializer(FarmRelatedSerializer):
    class Meta:
        model = Animal
        fields = '__all__'

class AnimalGroupSerializer(FarmRelatedSerializer):
    class Meta:
        model = AnimalGroup
        fields = '__all__'